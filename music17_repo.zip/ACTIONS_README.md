# GitHub Actions build

Once this project is pushed to GitHub, the `android-build.yml` workflow will run automatically.
Go to the Actions tab, open the latest run, and download the artifact named `app-debug-apk`.
That APK is the debug build of Music17 and can be installed on Android devices for testing.
