Assets:
- Pixel font (not included). Recommended: 'Press Start 2P' from Google Fonts.
- Replace launcher icons in res/mipmap with your pixel-styled icons.
