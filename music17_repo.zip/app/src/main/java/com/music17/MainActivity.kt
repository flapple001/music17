package com.music17

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val fileUri = intent?.data
        if (fileUri != null) {
            // Play immediately if opened via file
            val i = Intent(this, PlayerService::class.java)
            i.putExtra("FILE_URI", fileUri.toString())
            startForegroundService(i)
            finish()
            return
        }

        setContent {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Button(onClick = { startPlayFavorite() }) {
                    Text(text = "Play")
                }
            }
        }
    }

    private fun startPlayFavorite() {
        val i = Intent(this, PlayerService::class.java)
        startForegroundService(i)
        // Keep minimal UI; the service handles playback.
        finish()
    }
}
